# Complaint System

### Version
1.0.0

## 📝 Usage

### Installation

```sh
$ npm install
```

### Run

```sh
$ npm start
```

## See it Live [HERE](http://complaint-system.herokuapp.com/)

### ScreenShot

![Screenshot (2)](https://user-images.githubusercontent.com/34777376/56275958-520d6200-611f-11e9-9e65-d4566940425d.png)

![Screenshot (1)](https://user-images.githubusercontent.com/34777376/56276083-84b75a80-611f-11e9-8bbd-895feb274a10.png)

![Screenshot (3)](https://user-images.githubusercontent.com/34777376/56276092-8719b480-611f-11e9-932c-bde83b132c2b.png)

![Screenshot (4)](https://user-images.githubusercontent.com/34777376/56276133-9993ee00-611f-11e9-8922-ecb7ffe6af87.png)

![Screenshot (5)](https://user-images.githubusercontent.com/34777376/56276144-9ef13880-611f-11e9-92e5-1a1a26b82967.png)
